# Module Người 5 (Web) — bản khớp MySQL/mysql2

Viết đúng theo style repo hiện có: MySQL thuần qua `mysql2` (callback), response
lỗi dạng `{ error: '...' }`, `verifyToken` / `checkRole` từ `middleware/authMiddleware.js`,
`req.user = { id, role }` giải mã từ JWT.

## 1. Cách chạy schema

Mở kết nối MySQL của nhóm (cùng database với bảng `users` đã có), chạy:

```
mysql -u <user> -p <database> < sql/schema.sql
```

Các bảng tạo mới: `reviews`, `photo_collections`, `photos`, `posts`, `workshops`,
`workshop_registrations`. Không đụng đến bảng `users` sẵn có.

## 2. Copy file vào repo

Copy đè vào đúng vị trí trong `backend/`:

```
backend/
├── controllers/
│   ├── reviewController.js
│   ├── collectionController.js
│   ├── postController.js
│   └── workshopController.js
└── routes/
    ├── reviewRoutes.js
    ├── collectionRoutes.js
    ├── postRoutes.js
    └── workshopRoutes.js
```

**Không copy `config/db.js`** — dùng file `config/db.js` sẵn có của nhóm trưởng
(mình chỉ dùng nó để tham chiếu style, không tạo lại).

## 3. Gắn route vào file chính (index.js / server.js)

Thêm 4 dòng sau vào chỗ đang khai báo `authRoutes` / `userRoutes`:

```js
const reviewRoutes = require('./routes/reviewRoutes');
app.use('/api/reviews', reviewRoutes);

const collectionRoutes = require('./routes/collectionRoutes');
app.use('/api/collections', collectionRoutes);

const postRoutes = require('./routes/postRoutes');
app.use('/api/posts', postRoutes);

const workshopRoutes = require('./routes/workshopRoutes');
app.use('/api/workshops', workshopRoutes);
```

## 4. Điểm cần tự kiểm tra / chỉnh lại

- **Tên role 'expert'** trong `workshopRoutes.js` (`checkRole('expert')`) — đổi lại
  đúng tên role nhóm đang dùng trong bảng `users` (vd: `'organizer'`, `'admin'`...)
  nếu không phải `'expert'`.
- Vì `config/db.js` dùng `mysql.createConnection` (1 kết nối duy nhất, không phải
  pool), transaction trong `registerWorkshop`/`cancelRegistration` dùng
  `db.beginTransaction()` / `db.commit()` / `db.rollback()` trực tiếp trên connection
  đó — đúng với cách kết nối hiện tại, không cần đổi sang pool.
- Nếu sau này nhóm đổi `createConnection` thành `createPool`, transaction phải lấy
  connection riêng qua `pool.getConnection()` trước khi `beginTransaction` — báo mình
  nếu đổi để mình sửa lại.

## 5. Danh sách API

### Reviews
| Method | Endpoint | Auth | Mô tả |
|---|---|---|---|
| POST | /api/reviews | ✅ | Tạo đánh giá |
| GET | /api/reviews/:targetId?target_type=studio | ❌ | Xem đánh giá theo đối tượng |
| DELETE | /api/reviews/:id | ✅ (chủ sở hữu) | Xoá đánh giá |

### Photo Collections
| Method | Endpoint | Auth | Mô tả |
|---|---|---|---|
| GET | /api/collections | ✅ | Danh sách bộ sưu tập của tôi |
| POST | /api/collections | ✅ | Tạo bộ sưu tập |
| GET | /api/collections/:id | ✅ | Chi tiết bộ sưu tập + ảnh |
| POST | /api/collections/:id/photos | ✅ | Thêm ảnh vào bộ sưu tập |
| DELETE | /api/collections/:id | ✅ (chủ sở hữu) | Xoá bộ sưu tập |

### Posts (Community)
| Method | Endpoint | Auth | Mô tả |
|---|---|---|---|
| GET | /api/posts?type=guide | ❌ | Danh sách bài viết |
| GET | /api/posts/:id | ❌ | Chi tiết bài viết |
| POST | /api/posts | ✅ | Đăng bài |
| PUT | /api/posts/:id | ✅ (tác giả) | Sửa bài |
| DELETE | /api/posts/:id | ✅ (tác giả) | Xoá bài |

### Workshops
| Method | Endpoint | Auth | Mô tả |
|---|---|---|---|
| GET | /api/workshops | ❌ | Danh sách workshop |
| GET | /api/workshops/:id | ❌ | Chi tiết workshop |
| POST | /api/workshops | ✅ (role expert) | Tạo workshop |
| POST | /api/workshops/:id/register | ✅ | Đăng ký tham gia (transaction-safe) |
| DELETE | /api/workshops/:id/register | ✅ | Huỷ đăng ký |

## 6. Bước tiếp theo

Nếu cần, mình có thể viết tiếp 4 trang React/Next.js tương ứng
(`/reviews`, `/my-collections`, `/community`, `/community/workshops`) gọi thẳng
vào các API trên.
