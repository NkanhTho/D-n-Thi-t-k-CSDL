const express = require('express');
const router = express.Router();
const db = require('../config/db');

// Sửa lại Middleware theo chuẩn chung của nhóm
const { verifyToken, checkRole } = require('../middleware/authMiddleware');
const bookingController = require('../controllers/bookingController');

// ==========================================
// 1. CÁC API ĐẶT CHỖ (GỌI TỪ CONTROLLER)
// ==========================================
router.post('/bookings/check-availability', bookingController.checkAvailability);
router.post('/bookings', verifyToken, bookingController.createBooking);
router.post('/bookings/check-in', verifyToken, checkRole('provider'), bookingController.checkIn);
router.post('/bookings/check-out', verifyToken, checkRole('provider'), bookingController.checkOut);

// ==========================================
// 2. GIỮ NGUYÊN TOÀN BỘ CÁC API KHÔNG GIAN (SPACES)
// ==========================================
router.get('/spaces', async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM spaces WHERE status = "AVAILABLE"');
        res.json(rows);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

router.post('/spaces', verifyToken, checkRole('provider'), async (req, res) => {
    const { name, type, description, capacity, hourlyRate, operatingHours, specifications } = req.body;
    try {
        const [result] = await db.query(
            `INSERT INTO spaces (provider_id, name, type, description, capacity, hourly_rate, operating_hours, specifications)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
            [req.user.id, name, type, description, capacity, hourlyRate, JSON.stringify(operatingHours), JSON.stringify(specifications)]
        );
        res.status(201).json({ message: 'Thêm không gian thành công!', spaceId: result.insertId });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

router.put('/spaces/:id', verifyToken, checkRole('provider'), async (req, res) => {
    const { name, description, capacity, hourlyRate, status } = req.body;
    try {
        await db.query(
            `UPDATE spaces SET name = ?, description = ?, capacity = ?, hourly_rate = ?, status = ? WHERE id = ? AND provider_id = ?`,
            [name, description, capacity, hourlyRate, status, req.params.id, req.user.id]
        );
        res.json({ message: 'Cập nhật không gian thành công!' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

router.delete('/spaces/:id', verifyToken, checkRole('provider'), async (req, res) => {
    try {
        await db.query('DELETE FROM spaces WHERE id = ? AND provider_id = ?', [req.params.id, req.user.id]);
        res.json({ message: 'Xóa không gian thành công!' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// ==========================================
// 3. GIỮ NGUYÊN TOÀN BỘ CÁC API THIẾT BỊ (RESOURCES)
// ==========================================
router.get('/spaces/:spaceId/resources', async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM resources WHERE space_id = ? AND status = "AVAILABLE"', [req.params.spaceId]);
        res.json(rows);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

router.post('/resources', verifyToken, checkRole('provider'), async (req, res) => {
    const { spaceId, name, category, serialNumber, rentalPrice } = req.body;
    try {
        const [result] = await db.query(
            `INSERT INTO resources (space_id, name, category, serial_number, rental_price) VALUES (?, ?, ?, ?, ?)`,
            [spaceId, name, category, serialNumber, rentalPrice]
        );
        res.status(201).json({ message: 'Thêm thiết bị thành công!', resourceId: result.insertId });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;