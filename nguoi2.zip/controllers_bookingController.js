const db = require('../config/db');
const crypto = require('crypto');

// 1. Kiểm tra phòng trống
exports.checkAvailability = async (req, res) => {
    const { spaceId, startTime, endTime } = req.body;
    try {
        const [spaceConflicts] = await db.query(
            `SELECT id FROM bookings 
             WHERE space_id = ? AND status IN ('PENDING', 'CONFIRMED', 'CHECKED_IN')
               AND (start_time < ? AND end_time > ?)`,
            [spaceId, endTime, startTime]
        );

        if (spaceConflicts.length > 0) {
            return res.status(200).json({ available: false, reason: 'Phòng đã có người đặt trong khung giờ này.' });
        }
        return res.status(200).json({ available: true, message: 'Phòng khả dụng.' });
    } catch (error) {
        return res.status(500).json({ error: error.message });
    }
};

// 2. Tạo đơn đặt chỗ (Transaction khóa an toàn)
exports.createBooking = async (req, res) => {
    const userId = req.user.id;
    const { spaceId, resourceIds, startTime, endTime, totalPrice } = req.body;
    const connection = await db.getConnection();

    try {
        await connection.beginTransaction();

        const [spaces] = await connection.query(
            `SELECT id, status FROM spaces WHERE id = ? FOR UPDATE`, 
            [spaceId]
        );

        if (!spaces.length || spaces[0].status !== 'AVAILABLE') {
            await connection.rollback();
            return res.status(400).json({ message: 'Phòng hiện không khả dụng.' });
        }

        const [spaceConflicts] = await connection.query(
            `SELECT id FROM bookings 
             WHERE space_id = ? 
               AND status IN ('PENDING', 'CONFIRMED', 'CHECKED_IN')
               AND (start_time < ? AND end_time > ?) 
             FOR UPDATE`,
            [spaceId, endTime, startTime]
        );

        if (spaceConflicts.length > 0) {
            await connection.rollback();
            return res.status(409).json({ message: 'Xung đột lịch: Khung giờ này vừa có người đặt.' });
        }

        if (resourceIds && resourceIds.length > 0) {
            const [resourceConflicts] = await connection.query(
                `SELECT br.resource_id 
                 FROM booking_resources br
                 JOIN bookings b ON br.booking_id = b.id
                 WHERE br.resource_id IN (?) 
                   AND b.status IN ('PENDING', 'CONFIRMED', 'CHECKED_IN')
                   AND (b.start_time < ? AND b.end_time > ?) 
                 FOR UPDATE`,
                [[resourceIds], endTime, startTime]
            );

            if (resourceConflicts.length > 0) {
                await connection.rollback();
                return res.status(409).json({ message: 'Xung đột: Thiết bị chọn kèm vừa bị người khác đặt.' });
            }
        }

        const qrCodeHash = crypto.createHash('sha256').update(`${userId}-${spaceId}-${Date.now()}`).digest('hex');

        const [bookingResult] = await connection.query(
            `INSERT INTO bookings (user_id, space_id, start_time, end_time, total_price, status, qr_code_hash)
             VALUES (?, ?, ?, ?, ?, 'PENDING', ?)`,
            [userId, spaceId, startTime, endTime, totalPrice, qrCodeHash]
        );

        const newBookingId = bookingResult.insertId;

        if (resourceIds && resourceIds.length > 0) {
            const resourceValues = resourceIds.map(resId => [newBookingId, resId, 1]);
            await connection.query(
                `INSERT INTO booking_resources (booking_id, resource_id, quantity) VALUES ?`,
                [resourceValues]
            );
        }

        await connection.commit();

        return res.status(201).json({
            message: 'Tạo đơn đặt chỗ thành công!',
            bookingId: newBookingId,
            qrCodeHash: qrCodeHash
        });

    } catch (error) {
        await connection.rollback();
        return res.status(500).json({ error: 'Lỗi hệ thống: ' + error.message });
    } finally {
        connection.release();
    }
};

// 3. Check-in
exports.checkIn = async (req, res) => {
    const { bookingId, qrCodeHash } = req.body;
    try {
        const [booking] = await db.query(`SELECT * FROM bookings WHERE id = ? AND qr_code_hash = ?`, [bookingId, qrCodeHash]);
        if (!booking.length) return res.status(404).json({ message: 'Mã QR không hợp lệ.' });

        await db.query(`UPDATE bookings SET status = 'CHECKED_IN' WHERE id = ?`, [bookingId]);
        return res.status(200).json({ message: 'Check-in thành công!' });
    } catch (error) {
        return res.status(500).json({ error: error.message });
    }
};

// 4. Check-out
exports.checkOut = async (req, res) => {
    const { bookingId } = req.body;
    try {
        const [booking] = await db.query(`SELECT * FROM bookings WHERE id = ?`, [bookingId]);
        if (!booking.length) return res.status(404).json({ message: 'Không tìm thấy đơn đặt chỗ.' });

        await db.query(`UPDATE bookings SET status = 'COMPLETED' WHERE id = ?`, [bookingId]);
        return res.status(200).json({ message: 'Check-out hoàn tất thành công!' });
    } catch (error) {
        return res.status(500).json({ error: error.message });
    }
};