// Khai báo đường dẫn đến file Routes mới của Người 2
const bookingRoutes = require('./routes/bookingRoutes');

// Nhúng toàn bộ API của Người 2 vào hệ thống
app.use('/api', bookingRoutes);