import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

// Chặn các trang yêu cầu đăng nhập: đặt chỗ, thanh toán, lịch sử, trang cá nhân
export default function ProtectedRoute({ children }) {
  const { isLoggedIn, loading } = useAuth();
  const location = useLocation();

  if (loading) return <p className="muted">Đang tải…</p>;
  if (!isLoggedIn) return <Navigate to="/login" replace state={{ from: location }} />;
  return children;
}
