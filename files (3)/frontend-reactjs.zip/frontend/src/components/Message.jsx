// Hộp thông báo dùng chung cho lỗi / thành công / gợi ý
export default function Message({ type = 'info', children }) {
  if (!children) return null;
  return <div className={`message message-${type}`}>{children}</div>;
}
