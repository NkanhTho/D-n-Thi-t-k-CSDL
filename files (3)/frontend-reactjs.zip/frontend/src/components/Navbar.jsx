import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function Navbar() {
  const { isLoggedIn, user, signOut } = useAuth();
  const navigate = useNavigate();

  function handleSignOut() {
    signOut();
    navigate('/login');
  }

  return (
    <header className="navbar">
      <div className="container navbar-inner">
        <Link to="/" className="brand">
          Film Photo Platform
        </Link>

        <nav className="nav-links">
          <NavLink to="/spaces">Tìm phòng</NavLink>
          {isLoggedIn && <NavLink to="/bookings">Lịch sử đặt chỗ</NavLink>}
          {isLoggedIn && <NavLink to="/profile">Trang cá nhân</NavLink>}
        </nav>

        <div className="nav-actions">
          {isLoggedIn ? (
            <>
              <span className="muted">{user?.name || 'Tài khoản'}</span>
              <button type="button" className="btn btn-ghost" onClick={handleSignOut}>
                Đăng xuất
              </button>
            </>
          ) : (
            <>
              <Link to="/login" className="btn btn-ghost">Đăng nhập</Link>
              <Link to="/register" className="btn btn-primary">Đăng ký</Link>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
