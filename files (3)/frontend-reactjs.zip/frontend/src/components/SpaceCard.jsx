import { Link } from 'react-router-dom';
import { formatPrice, SPACE_TYPE_LABEL, getArea } from '../utils/format';

export default function SpaceCard({ space }) {
  const area = getArea(space);

  return (
    <article className="card">
      <div className="card-head">
        <h3>{space.name}</h3>
        <span className="tag">{SPACE_TYPE_LABEL[space.type] || space.type}</span>
      </div>

      <dl className="kv">
        <div><dt>Khu vực</dt><dd>{area || 'Chưa cập nhật'}</dd></div>
        <div><dt>Sức chứa</dt><dd>{space.capacity} người</dd></div>
        <div><dt>Giá thuê</dt><dd>{formatPrice(space.hourly_rate)}/giờ</dd></div>
      </dl>

      {space.description && <p className="desc">{space.description}</p>}

      <Link to={`/spaces/${space.id}`} className="btn btn-primary">
        Xem chi tiết
      </Link>
    </article>
  );
}
