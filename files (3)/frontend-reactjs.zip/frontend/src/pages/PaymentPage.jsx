import { useState } from 'react';
import { Link, useLocation, useParams } from 'react-router-dom';
import * as paymentApi from '../api/paymentApi';
import { getErrorMessage } from '../api/client';
import Message from '../components/Message';
import { formatPrice, formatDatetime } from '../utils/format';

export default function PaymentPage() {
  const { bookingId } = useParams();
  const { state } = useLocation(); // dữ liệu chuyển sang từ trang đặt chỗ

  const [method, setMethod] = useState('vnpay'); // transactions.payment_method
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  async function handlePay() {
    setError('');
    setSubmitting(true);
    try {
      const res =
        method === 'vnpay'
          ? await paymentApi.createVnpayPayment(Number(bookingId))
          : await paymentApi.createMomoPayment(Number(bookingId));

      if (!res.data?.paymentUrl) {
        setError('Cổng thanh toán chưa trả về đường dẫn. Liên hệ hỗ trợ nhé.');
        return;
      }
      // Rời khỏi ứng dụng sang cổng thanh toán; backend cập nhật booking sang CONFIRMED khi thành công
      window.location.href = res.data.paymentUrl;
    } catch (err) {
      setError(getErrorMessage(err, 'Không tạo được yêu cầu thanh toán.'));
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="narrow">
      <h1>Thanh toán</h1>
      <p className="muted">Đơn đặt chỗ #{bookingId} đang chờ thanh toán.</p>

      <Message type="error">{error}</Message>

      <section className="summary">
        <h2>Thông tin đơn</h2>
        <dl className="kv kv-wide">
          <div><dt>Mã đơn</dt><dd>#{bookingId}</dd></div>
          {state?.spaceName && <div><dt>Phòng</dt><dd>{state.spaceName}</dd></div>}
          {state?.startTime && (
            <div>
              <dt>Thời gian</dt>
              <dd>{formatDatetime(state.startTime)} → {formatDatetime(state.endTime)}</dd>
            </div>
          )}
          <div>
            <dt>Số tiền</dt>
            <dd><strong>{state?.amount != null ? formatPrice(state.amount) : 'Theo đơn đã tạo'}</strong></dd>
          </div>
        </dl>
      </section>

      <section>
        <h2>Chọn cách thanh toán</h2>
        <ul className="checklist">
          <li>
            <label className="inline">
              <input
                type="radio"
                name="method"
                value="vnpay"
                checked={method === 'vnpay'}
                onChange={(e) => setMethod(e.target.value)}
              />
              <span>VNPay — thẻ ngân hàng, QR ngân hàng</span>
            </label>
          </li>
          <li>
            <label className="inline">
              <input
                type="radio"
                name="method"
                value="momo"
                checked={method === 'momo'}
                onChange={(e) => setMethod(e.target.value)}
              />
              <span>MoMo — ví điện tử</span>
            </label>
          </li>
        </ul>
      </section>

      <div className="actions">
        <Link to="/bookings" className="btn btn-ghost">Để sau</Link>
        <button type="button" className="btn btn-primary" onClick={handlePay} disabled={submitting}>
          {submitting ? 'Đang chuyển tới cổng thanh toán…' : 'Thanh toán ngay'}
        </button>
      </div>

      <p className="muted">
        Sau khi thanh toán xong, đơn chuyển sang trạng thái “Đã xác nhận”. Nếu chưa thấy cập nhật,
        mở lại trang lịch sử đặt chỗ sau vài giây.
      </p>
    </div>
  );
}
