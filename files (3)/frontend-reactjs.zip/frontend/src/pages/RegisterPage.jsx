import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import * as userApi from '../api/userApi';
import { getErrorMessage } from '../api/client';
import Message from '../components/Message';

export default function RegisterPage() {
  const [form, setForm] = useState({
    name: '',
    email: '',
    password: '',
    confirm: '',
    role: 'customer', // cột users.role; provider cần admin duyệt (users.is_approved)
  });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const navigate = useNavigate();

  function handleChange(e) {
    setForm({ ...form, [e.target.name]: e.target.value });
  }

  function validate() {
    if (!form.name.trim()) return 'Nhập tên của bạn.';
    if (!form.email.trim()) return 'Nhập email.';
    if (form.password.length < 6) return 'Mật khẩu cần ít nhất 6 ký tự.';
    if (form.password !== form.confirm) return 'Hai lần nhập mật khẩu chưa giống nhau.';
    return '';
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    setSuccess('');

    const invalid = validate();
    if (invalid) {
      setError(invalid);
      return;
    }

    setSubmitting(true);
    try {
      await userApi.register({
        name: form.name.trim(),
        email: form.email.trim(),
        password: form.password,
        role: form.role,
      });
      setSuccess('Đăng ký thành công. Đang chuyển sang trang đăng nhập…');
      setTimeout(() => navigate('/login'), 1200);
    } catch (err) {
      setError(getErrorMessage(err, 'Đăng ký không thành công.'));
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="auth-page">
      <h1>Đăng ký</h1>
      <p className="muted">Tạo tài khoản để dùng nền tảng.</p>

      <Message type="error">{error}</Message>
      <Message type="success">{success}</Message>

      <form onSubmit={handleSubmit} className="form">
        <label>
          Họ và tên
          <input type="text" name="name" value={form.name} onChange={handleChange} />
        </label>

        <label>
          Email
          <input type="email" name="email" value={form.email} onChange={handleChange} />
        </label>

        <label>
          Mật khẩu
          <input
            type="password"
            name="password"
            value={form.password}
            onChange={handleChange}
            autoComplete="new-password"
          />
        </label>

        <label>
          Nhập lại mật khẩu
          <input
            type="password"
            name="confirm"
            value={form.confirm}
            onChange={handleChange}
            autoComplete="new-password"
          />
        </label>

        <label>
          Bạn là
          <select name="role" value={form.role} onChange={handleChange}>
            <option value="customer">Nhiếp ảnh gia (khách hàng)</option>
            <option value="provider">Nhà cung cấp dịch vụ</option>
            <option value="expert">Chuyên gia nhiếp ảnh</option>
          </select>
        </label>

        <button type="submit" className="btn btn-primary" disabled={submitting}>
          {submitting ? 'Đang tạo tài khoản…' : 'Tạo tài khoản'}
        </button>
      </form>

      <p className="muted">
        Đã có tài khoản? <Link to="/login">Đăng nhập</Link>
      </p>
    </div>
  );
}
