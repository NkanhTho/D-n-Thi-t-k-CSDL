import { useEffect, useState } from 'react';
import * as userApi from '../api/userApi';
import { getErrorMessage } from '../api/client';
import Message from '../components/Message';
import { useAuth } from '../context/AuthContext';
import { formatDatetime } from '../utils/format';

const ROLE_LABEL = {
  customer: 'Nhiếp ảnh gia',
  provider: 'Nhà cung cấp dịch vụ',
  expert: 'Chuyên gia nhiếp ảnh',
  admin: 'Quản trị viên',
};

export default function ProfilePage() {
  const { user, setUser } = useAuth();

  const [form, setForm] = useState({ name: '', phone: '' });
  const [profileMsg, setProfileMsg] = useState('');
  const [profileError, setProfileError] = useState('');
  const [savingProfile, setSavingProfile] = useState(false);

  const [complaintContent, setComplaintContent] = useState('');
  const [complaintBookingId, setComplaintBookingId] = useState('');
  const [complaints, setComplaints] = useState([]);
  const [supportMsg, setSupportMsg] = useState('');
  const [supportError, setSupportError] = useState('');
  const [sending, setSending] = useState(false);

  useEffect(() => {
    if (user) setForm({ name: user.name || '', phone: user.phone || '' });
  }, [user]);

  useEffect(() => {
    userApi
      .getMyComplaints()
      .then((res) => setComplaints(Array.isArray(res.data) ? res.data : []))
      .catch(() => setComplaints([])); // route hỗ trợ có thể chưa được mount, không chặn trang
  }, []);

  async function handleSaveProfile(e) {
    e.preventDefault();
    setProfileError('');
    setProfileMsg('');

    if (!form.name.trim()) {
      setProfileError('Tên không được để trống.');
      return;
    }

    setSavingProfile(true);
    try {
      await userApi.updateProfile({ name: form.name.trim(), phone: form.phone.trim() });
      const res = await userApi.getProfile();
      setUser(res.data);
      setProfileMsg('Đã lưu thay đổi.');
    } catch (err) {
      setProfileError(getErrorMessage(err, 'Không lưu được hồ sơ.'));
    } finally {
      setSavingProfile(false);
    }
  }

  async function handleSendComplaint(e) {
    e.preventDefault();
    setSupportError('');
    setSupportMsg('');

    if (complaintContent.trim().length < 10) {
      setSupportError('Mô tả vấn đề chi tiết hơn một chút (ít nhất 10 ký tự).');
      return;
    }

    setSending(true);
    try {
      await userApi.createComplaint({
        content: complaintContent.trim(),
        bookingId: complaintBookingId ? Number(complaintBookingId) : null,
      });
      setComplaintContent('');
      setComplaintBookingId('');
      setSupportMsg('Đã gửi yêu cầu. Quản trị viên sẽ phản hồi trong phần này.');
      const res = await userApi.getMyComplaints();
      setComplaints(Array.isArray(res.data) ? res.data : []);
    } catch (err) {
      setSupportError(getErrorMessage(err, 'Không gửi được yêu cầu hỗ trợ.'));
    } finally {
      setSending(false);
    }
  }

  return (
    <div className="narrow">
      <h1>Trang cá nhân</h1>

      <section>
        <h2>Hồ sơ</h2>
        <Message type="error">{profileError}</Message>
        <Message type="success">{profileMsg}</Message>

        <form className="form" onSubmit={handleSaveProfile}>
          <label>
            Họ và tên
            <input
              type="text"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
            />
          </label>

          <label>
            Số điện thoại
            <input
              type="tel"
              value={form.phone}
              onChange={(e) => setForm({ ...form, phone: e.target.value })}
            />
          </label>

          <label>
            Email
            <input type="email" value={user?.email || ''} readOnly />
            <span className="muted small">Email dùng để đăng nhập, không đổi được ở đây.</span>
          </label>

          <label>
            Vai trò
            <input type="text" value={ROLE_LABEL[user?.role] || user?.role || ''} readOnly />
          </label>

          <button type="submit" className="btn btn-primary" disabled={savingProfile}>
            {savingProfile ? 'Đang lưu…' : 'Lưu thay đổi'}
          </button>
        </form>
      </section>

      <section>
        <h2>Hỗ trợ</h2>
        <p className="muted">Gặp vấn đề với một đơn đặt chỗ? Gửi yêu cầu để quản trị viên xử lý.</p>

        <Message type="error">{supportError}</Message>
        <Message type="success">{supportMsg}</Message>

        <form className="form" onSubmit={handleSendComplaint}>
          <label>
            Mã đơn liên quan (không bắt buộc)
            <input
              type="number"
              min="1"
              value={complaintBookingId}
              onChange={(e) => setComplaintBookingId(e.target.value)}
              placeholder="VD: 12"
            />
          </label>

          <label>
            Nội dung
            <textarea
              rows="4"
              value={complaintContent}
              onChange={(e) => setComplaintContent(e.target.value)}
              placeholder="Mô tả vấn đề bạn gặp phải…"
            />
          </label>

          <button type="submit" className="btn btn-primary" disabled={sending}>
            {sending ? 'Đang gửi…' : 'Gửi yêu cầu'}
          </button>
        </form>

        <h3>Yêu cầu đã gửi</h3>
        {complaints.length === 0 ? (
          <p className="muted">Bạn chưa gửi yêu cầu nào.</p>
        ) : (
          <ul className="complaint-list">
            {complaints.map((c) => (
              <li key={c.id}>
                <div className="complaint-head">
                  <span className={`status status-${c.status}`}>
                    {c.status === 'resolved' ? 'Đã xử lý' : 'Đang mở'}
                  </span>
                  <span className="muted small">{formatDatetime(c.created_at)}</span>
                </div>
                <p>{c.content}</p>
                {c.admin_response && (
                  <p className="admin-reply">Phản hồi: {c.admin_response}</p>
                )}
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
