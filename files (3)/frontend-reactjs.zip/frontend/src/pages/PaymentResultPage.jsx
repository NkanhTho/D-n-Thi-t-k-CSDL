import { useEffect, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import * as paymentApi from '../api/paymentApi';
import { getErrorMessage } from '../api/client';
import Message from '../components/Message';
import { formatPrice } from '../utils/format';

// Trang nhận redirect từ VNPay/MoMo (returnUrl trỏ về /payment-result?orderId=...)
// Trạng thái thật nằm ở bảng transactions, lấy qua GET /payments/status/:orderId
export default function PaymentResultPage() {
  const [params] = useSearchParams();
  const orderId = params.get('orderId') || params.get('vnp_TxnRef');

  const [transaction, setTransaction] = useState(null);
  const [loading, setLoading] = useState(!!orderId);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!orderId) {
      setError('Thiếu mã giao dịch trong đường dẫn trả về.');
      return;
    }
    paymentApi
      .getTransactionStatus(orderId)
      .then((res) => setTransaction(res.data))
      .catch((err) => setError(getErrorMessage(err, 'Không tra được trạng thái giao dịch.')))
      .finally(() => setLoading(false));
  }, [orderId]);

  return (
    <div className="narrow">
      <h1>Kết quả thanh toán</h1>

      <Message type="error">{error}</Message>

      {loading && <p className="muted">Đang tra trạng thái giao dịch…</p>}

      {transaction && (
        <>
          {transaction.status === 'success' && (
            <Message type="success">
              Thanh toán thành công. Đơn đặt chỗ đã được xác nhận.
            </Message>
          )}
          {transaction.status === 'failed' && (
            <Message type="error">
              Thanh toán thất bại. Đơn vẫn đang chờ thanh toán, bạn có thể thử lại.
            </Message>
          )}
          {transaction.status === 'pending' && (
            <Message type="info">
              Giao dịch đang chờ xác nhận từ cổng thanh toán. Tải lại trang sau vài giây.
            </Message>
          )}

          <dl className="kv kv-wide">
            <div><dt>Mã giao dịch</dt><dd>{transaction.order_id}</dd></div>
            <div><dt>Đơn đặt chỗ</dt><dd>#{transaction.booking_id}</dd></div>
            <div><dt>Số tiền</dt><dd>{formatPrice(transaction.amount)}</dd></div>
            <div><dt>Cách thanh toán</dt><dd>{transaction.payment_method}</dd></div>
          </dl>
        </>
      )}

      <div className="actions">
        <Link to="/bookings" className="btn btn-primary">Xem lịch sử đặt chỗ</Link>
        {transaction?.status === 'failed' && (
          <Link to={`/payment/${transaction.booking_id}`} className="btn btn-ghost">
            Thử thanh toán lại
          </Link>
        )}
      </div>
    </div>
  );
}
