import { useEffect, useMemo, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import * as spaceApi from '../api/spaceApi';
import * as bookingApi from '../api/bookingApi';
import { getErrorMessage } from '../api/client';
import Message from '../components/Message';
import {
  formatPrice,
  buildDatetime,
  todayStr,
  RESOURCE_CATEGORY_LABEL,
  SPACE_TYPE_LABEL,
} from '../utils/format';

// Khung giờ mặc định 8:00 - 21:00. Nếu operating_hours có open/close thì dùng theo phòng.
const DEFAULT_OPEN = 8;
const DEFAULT_CLOSE = 21;

export default function BookingPage() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [space, setSpace] = useState(null);
  const [resources, setResources] = useState([]);
  const [loading, setLoading] = useState(true);

  const [date, setDate] = useState(todayStr());
  const [startHour, setStartHour] = useState(9);
  const [hours, setHours] = useState(2);
  const [pickedResources, setPickedResources] = useState([]);

  const [checking, setChecking] = useState(false);
  const [availability, setAvailability] = useState(null); // null | true | false
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  useEffect(() => {
    let ignore = false;
    Promise.all([spaceApi.getSpaceById(id), spaceApi.getSpaceResources(id)])
      .then(([spaceData, resourceRes]) => {
        if (ignore) return;
        setSpace(spaceData);
        setResources(Array.isArray(resourceRes.data) ? resourceRes.data : []);
      })
      .catch((err) => {
        if (!ignore) setError(getErrorMessage(err, 'Không tải được thông tin phòng.'));
      })
      .finally(() => {
        if (!ignore) setLoading(false);
      });
    return () => {
      ignore = true;
    };
  }, [id]);

  const startTime = buildDatetime(date, startHour);
  const endTime = buildDatetime(date, startHour + Number(hours));

  const totalPrice = useMemo(() => {
    if (!space) return 0;
    const roomCost = Number(space.hourly_rate) * Number(hours);
    const equipmentCost = resources
      .filter((r) => pickedResources.includes(r.id))
      .reduce((sum, r) => sum + Number(r.rental_price || 0), 0);
    return roomCost + equipmentCost;
  }, [space, hours, resources, pickedResources]);

  const hourOptions = [];
  for (let h = DEFAULT_OPEN; h < DEFAULT_CLOSE; h += 1) hourOptions.push(h);

  const maxHours = Math.max(1, DEFAULT_CLOSE - startHour);

  // Đổi lựa chọn nào cũng phải kiểm tra trống lại từ đầu
  function resetAvailability() {
    setAvailability(null);
    setNotice('');
  }

  function toggleResource(resourceId) {
    setPickedResources((prev) =>
      prev.includes(resourceId) ? prev.filter((x) => x !== resourceId) : [...prev, resourceId]
    );
    resetAvailability();
  }

  async function handleCheck() {
    setError('');
    setNotice('');
    setChecking(true);
    try {
      const res = await bookingApi.checkAvailability({
        spaceId: Number(id),
        resourceIds: pickedResources,
        startTime,
        endTime,
      });
      const ok = res.data?.available !== false;
      setAvailability(ok);
      setNotice(
        ok
          ? 'Khung giờ này còn trống. Bạn có thể xác nhận đặt chỗ.'
          : res.data?.reason || 'Khung giờ này đã có người đặt. Chọn giờ khác nhé.'
      );
    } catch (err) {
      setAvailability(null);
      setError(getErrorMessage(err, 'Không kiểm tra được tình trạng phòng.'));
    } finally {
      setChecking(false);
    }
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');

    if (availability !== true) {
      setError('Bấm "Kiểm tra phòng trống" trước khi đặt chỗ.');
      return;
    }

    setSubmitting(true);
    try {
      const res = await bookingApi.createBooking({
        spaceId: Number(id),
        resourceIds: pickedResources,
        startTime,
        endTime,
        totalPrice,
      });
      // Booking vừa tạo ở trạng thái PENDING -> chuyển sang trang thanh toán
      navigate(`/payment/${res.data.bookingId}`, {
        state: {
          bookingId: res.data.bookingId,
          qrCodeHash: res.data.qrCodeHash,
          amount: totalPrice,
          spaceName: space?.name,
          startTime,
          endTime,
        },
      });
    } catch (err) {
      // 409 = Người 2 phát hiện xung đột lịch ở tầng transaction
      setAvailability(null);
      setError(getErrorMessage(err, 'Tạo đơn đặt chỗ không thành công.'));
    } finally {
      setSubmitting(false);
    }
  }

  if (loading) return <p className="muted">Đang tải…</p>;
  if (!space) return <Message type="error">{error || 'Không tìm thấy phòng.'}</Message>;

  return (
    <div>
      <h1>Đặt chỗ: {space.name}</h1>
      <p className="muted">
        {SPACE_TYPE_LABEL[space.type] || space.type} · {formatPrice(space.hourly_rate)}/giờ
      </p>

      <Message type="error">{error}</Message>
      {notice && <Message type={availability ? 'success' : 'info'}>{notice}</Message>}

      <form className="form form-wide" onSubmit={handleSubmit}>
        <section>
          <h2>Chọn khung giờ</h2>
          <div className="row">
            <label>
              Ngày
              <input
                type="date"
                value={date}
                min={todayStr()}
                onChange={(e) => {
                  setDate(e.target.value);
                  resetAvailability();
                }}
              />
            </label>

            <label>
              Giờ bắt đầu
              <select
                value={startHour}
                onChange={(e) => {
                  setStartHour(Number(e.target.value));
                  resetAvailability();
                }}
              >
                {hourOptions.map((h) => (
                  <option key={h} value={h}>{String(h).padStart(2, '0')}:00</option>
                ))}
              </select>
            </label>

            <label>
              Số giờ thuê
              <select
                value={hours}
                onChange={(e) => {
                  setHours(Number(e.target.value));
                  resetAvailability();
                }}
              >
                {Array.from({ length: maxHours }, (_, i) => i + 1).map((h) => (
                  <option key={h} value={h}>{h} giờ</option>
                ))}
              </select>
            </label>
          </div>
          <p className="muted">
            Khung giờ đã chọn: {String(startHour).padStart(2, '0')}:00 –{' '}
            {String(startHour + Number(hours)).padStart(2, '0')}:00 ngày {date}
          </p>
        </section>

        <section>
          <h2>Thuê thêm thiết bị</h2>
          {resources.length === 0 ? (
            <p className="muted">Phòng này chưa có thiết bị cho thuê.</p>
          ) : (
            <ul className="checklist">
              {resources.map((r) => (
                <li key={r.id}>
                  <label className="inline">
                    <input
                      type="checkbox"
                      checked={pickedResources.includes(r.id)}
                      onChange={() => toggleResource(r.id)}
                    />
                    <span>
                      {r.name}{' '}
                      <span className="muted">
                        ({RESOURCE_CATEGORY_LABEL[r.category] || r.category}) ·{' '}
                        {Number(r.rental_price) > 0 ? formatPrice(r.rental_price) : 'Miễn phí'}
                      </span>
                    </span>
                  </label>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section className="summary">
          <h2>Tạm tính</h2>
          <dl className="kv kv-wide">
            <div>
              <dt>Tiền phòng</dt>
              <dd>{formatPrice(Number(space.hourly_rate) * Number(hours))} ({hours} giờ)</dd>
            </div>
            <div>
              <dt>Tiền thiết bị</dt>
              <dd>
                {formatPrice(
                  resources
                    .filter((r) => pickedResources.includes(r.id))
                    .reduce((s, r) => s + Number(r.rental_price || 0), 0)
                )}
              </dd>
            </div>
            <div>
              <dt>Tổng cộng</dt>
              <dd><strong>{formatPrice(totalPrice)}</strong></dd>
            </div>
          </dl>
        </section>

        <div className="actions">
          <button type="button" className="btn btn-ghost" onClick={handleCheck} disabled={checking}>
            {checking ? 'Đang kiểm tra…' : 'Kiểm tra phòng trống'}
          </button>
          <button
            type="submit"
            className="btn btn-primary"
            disabled={submitting || availability !== true}
          >
            {submitting ? 'Đang tạo đơn…' : 'Xác nhận và thanh toán'}
          </button>
        </div>
      </form>
    </div>
  );
}
