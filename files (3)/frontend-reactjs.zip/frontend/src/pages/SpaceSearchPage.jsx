import { useEffect, useMemo, useState } from 'react';
import * as spaceApi from '../api/spaceApi';
import { getErrorMessage } from '../api/client';
import Message from '../components/Message';
import SpaceCard from '../components/SpaceCard';
import { getArea } from '../utils/format';

const EMPTY_FILTER = { keyword: '', area: '', type: '', maxPrice: '' };

export default function SpaceSearchPage() {
  const [spaces, setSpaces] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [filter, setFilter] = useState(EMPTY_FILTER);

  // Backend trả về toàn bộ phòng AVAILABLE, chưa có query param -> lọc phía client
  useEffect(() => {
    let ignore = false;
    spaceApi
      .getSpaces()
      .then((res) => {
        if (!ignore) setSpaces(Array.isArray(res.data) ? res.data : []);
      })
      .catch((err) => {
        if (!ignore) setError(getErrorMessage(err, 'Không tải được danh sách phòng.'));
      })
      .finally(() => {
        if (!ignore) setLoading(false);
      });
    return () => {
      ignore = true;
    };
  }, []);

  // Danh sách khu vực lấy từ dữ liệu thật để đổ vào ô chọn
  const areas = useMemo(() => {
    const set = new Set();
    spaces.forEach((s) => {
      const a = getArea(s);
      if (a) set.add(a);
    });
    return Array.from(set).sort();
  }, [spaces]);

  const results = useMemo(() => {
    const keyword = filter.keyword.trim().toLowerCase();
    const maxPrice = filter.maxPrice ? Number(filter.maxPrice) : null;

    return spaces.filter((s) => {
      if (keyword) {
        const haystack = `${s.name} ${s.description || ''}`.toLowerCase();
        if (!haystack.includes(keyword)) return false;
      }
      if (filter.area && getArea(s) !== filter.area) return false;
      if (filter.type && s.type !== filter.type) return false;
      if (maxPrice !== null && Number(s.hourly_rate) > maxPrice) return false;
      return true;
    });
  }, [spaces, filter]);

  function handleChange(e) {
    setFilter({ ...filter, [e.target.name]: e.target.value });
  }

  return (
    <div>
      <h1>Tìm phòng tối và studio</h1>
      <p className="muted">Lọc theo khu vực, loại phòng và mức giá bạn muốn.</p>

      <Message type="error">{error}</Message>

      <form className="filter-bar" onSubmit={(e) => e.preventDefault()}>
        <label>
          Từ khoá
          <input
            type="text"
            name="keyword"
            value={filter.keyword}
            onChange={handleChange}
            placeholder="Tên phòng, mô tả…"
          />
        </label>

        <label>
          Khu vực
          <select name="area" value={filter.area} onChange={handleChange}>
            <option value="">Tất cả khu vực</option>
            {areas.map((a) => (
              <option key={a} value={a}>{a}</option>
            ))}
          </select>
        </label>

        <label>
          Loại phòng
          <select name="type" value={filter.type} onChange={handleChange}>
            <option value="">Tất cả</option>
            <option value="DARKROOM">Phòng tối</option>
            <option value="STUDIO">Studio chụp ảnh</option>
          </select>
        </label>

        <label>
          Giá tối đa mỗi giờ
          <input
            type="number"
            name="maxPrice"
            min="0"
            step="10000"
            value={filter.maxPrice}
            onChange={handleChange}
            placeholder="VD: 200000"
          />
        </label>

        <button type="button" className="btn btn-ghost" onClick={() => setFilter(EMPTY_FILTER)}>
          Xoá lọc
        </button>
      </form>

      {loading ? (
        <p className="muted">Đang tải danh sách phòng…</p>
      ) : results.length === 0 ? (
        <Message type="info">
          Không có phòng nào khớp với điều kiện lọc. Thử mở rộng khu vực hoặc tăng mức giá.
        </Message>
      ) : (
        <>
          <p className="muted">Tìm thấy {results.length} phòng.</p>
          <div className="grid">
            {results.map((s) => (
              <SpaceCard key={s.id} space={s} />
            ))}
          </div>
        </>
      )}
    </div>
  );
}
