import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import * as bookingApi from '../api/bookingApi';
import { getErrorMessage } from '../api/client';
import Message from '../components/Message';
import { formatPrice, formatDatetime, BOOKING_STATUS_LABEL } from '../utils/format';

const FILTERS = [
  { value: '', label: 'Tất cả' },
  { value: 'PENDING', label: 'Chờ thanh toán' },
  { value: 'CONFIRMED', label: 'Đã xác nhận' },
  { value: 'COMPLETED', label: 'Hoàn thành' },
  { value: 'CANCELLED', label: 'Đã huỷ' },
];

export default function BookingHistoryPage() {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [status, setStatus] = useState('');

  useEffect(() => {
    let ignore = false;
    bookingApi
      .getMyBookings()
      .then((res) => {
        if (!ignore) setBookings(Array.isArray(res.data) ? res.data : []);
      })
      .catch((err) => {
        if (ignore) return;
        // Endpoint GET /bookings/my chưa có ở backend -> nói rõ thay vì để trang trắng
        if (err.response?.status === 404) {
          setError(
            'Backend chưa có API lấy lịch sử đặt chỗ (GET /api/bookings/my). ' +
              'Xem file backend-patch/bookingHistory.patch.js để bổ sung.'
          );
        } else {
          setError(getErrorMessage(err, 'Không tải được lịch sử đặt chỗ.'));
        }
      })
      .finally(() => {
        if (!ignore) setLoading(false);
      });
    return () => {
      ignore = true;
    };
  }, []);

  const rows = useMemo(
    () => (status ? bookings.filter((b) => b.status === status) : bookings),
    [bookings, status]
  );

  return (
    <div>
      <h1>Lịch sử đặt chỗ</h1>
      <p className="muted">Toàn bộ đơn bạn đã đặt, kèm trạng thái và số tiền.</p>

      <Message type="error">{error}</Message>

      <div className="filter-bar">
        <label>
          Trạng thái
          <select value={status} onChange={(e) => setStatus(e.target.value)}>
            {FILTERS.map((f) => (
              <option key={f.value} value={f.value}>{f.label}</option>
            ))}
          </select>
        </label>
      </div>

      {loading ? (
        <p className="muted">Đang tải lịch sử…</p>
      ) : rows.length === 0 ? (
        <Message type="info">
          Chưa có đơn nào. <Link to="/spaces">Tìm một phòng tối hoặc studio</Link> để bắt đầu.
        </Message>
      ) : (
        <table className="table">
          <thead>
            <tr>
              <th>Mã đơn</th>
              <th>Phòng</th>
              <th>Thời gian</th>
              <th>Số tiền</th>
              <th>Trạng thái</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {rows.map((b) => (
              <tr key={b.id}>
                <td>#{b.id}</td>
                <td>{b.space_name || `Phòng #${b.space_id}`}</td>
                <td>
                  {formatDatetime(b.start_time)}
                  <br />
                  <span className="muted">đến {formatDatetime(b.end_time)}</span>
                </td>
                <td>{formatPrice(b.total_price)}</td>
                <td>
                  <span className={`status status-${String(b.status).toLowerCase()}`}>
                    {BOOKING_STATUS_LABEL[b.status] || b.status}
                  </span>
                </td>
                <td>
                  {b.status === 'PENDING' && (
                    <Link to={`/payment/${b.id}`} className="btn btn-small btn-primary">
                      Thanh toán
                    </Link>
                  )}
                  {b.status === 'CONFIRMED' && b.qr_code_hash && (
                    <span className="muted small">
                      Mã check-in: {String(b.qr_code_hash).slice(0, 8)}…
                    </span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
