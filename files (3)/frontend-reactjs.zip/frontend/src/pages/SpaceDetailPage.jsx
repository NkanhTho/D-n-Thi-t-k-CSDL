import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import * as spaceApi from '../api/spaceApi';
import { getErrorMessage } from '../api/client';
import Message from '../components/Message';
import {
  formatPrice,
  SPACE_TYPE_LABEL,
  RESOURCE_CATEGORY_LABEL,
  parseSpecs,
  getArea,
} from '../utils/format';

export default function SpaceDetailPage() {
  const { id } = useParams();
  const [space, setSpace] = useState(null);
  const [resources, setResources] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    let ignore = false;
    setLoading(true);

    Promise.all([spaceApi.getSpaceById(id), spaceApi.getSpaceResources(id)])
      .then(([spaceData, resourceRes]) => {
        if (ignore) return;
        setSpace(spaceData);
        setResources(Array.isArray(resourceRes.data) ? resourceRes.data : []);
      })
      .catch((err) => {
        if (!ignore) setError(getErrorMessage(err, 'Không tải được thông tin phòng.'));
      })
      .finally(() => {
        if (!ignore) setLoading(false);
      });

    return () => {
      ignore = true;
    };
  }, [id]);

  if (loading) return <p className="muted">Đang tải thông tin phòng…</p>;
  if (error) return <Message type="error">{error}</Message>;
  if (!space) return null;

  const specs = parseSpecs(space.specifications);
  const hours = parseSpecs(space.operating_hours);

  return (
    <div>
      <Link to="/spaces" className="back-link">Quay lại danh sách</Link>

      <div className="detail-head">
        <div>
          <h1>{space.name}</h1>
          <p className="muted">
            {SPACE_TYPE_LABEL[space.type] || space.type}
            {getArea(space) ? ` · ${getArea(space)}` : ''}
          </p>
        </div>
        <div className="price-box">
          <strong>{formatPrice(space.hourly_rate)}</strong>
          <span className="muted">mỗi giờ</span>
        </div>
      </div>

      {space.description && <p>{space.description}</p>}

      <section>
        <h2>Thông tin phòng</h2>
        <dl className="kv kv-wide">
          <div><dt>Sức chứa</dt><dd>{space.capacity} người</dd></div>
          <div><dt>Trạng thái</dt><dd>{space.status === 'AVAILABLE' ? 'Đang nhận đặt chỗ' : space.status}</dd></div>
          {Object.entries(specs).map(([key, value]) => (
            <div key={key}>
              <dt>{key}</dt>
              <dd>{typeof value === 'object' ? JSON.stringify(value) : String(value)}</dd>
            </div>
          ))}
        </dl>
      </section>

      {Object.keys(hours).length > 0 && (
        <section>
          <h2>Giờ hoạt động</h2>
          <dl className="kv kv-wide">
            {Object.entries(hours).map(([day, value]) => (
              <div key={day}>
                <dt>{day}</dt>
                <dd>{typeof value === 'object' ? JSON.stringify(value) : String(value)}</dd>
              </div>
            ))}
          </dl>
        </section>
      )}

      <section>
        <h2>Thiết bị có thể thuê kèm</h2>
        {resources.length === 0 ? (
          <p className="muted">Phòng này chưa đăng thiết bị cho thuê.</p>
        ) : (
          <table className="table">
            <thead>
              <tr>
                <th>Thiết bị</th>
                <th>Loại</th>
                <th>Giá thuê</th>
              </tr>
            </thead>
            <tbody>
              {resources.map((r) => (
                <tr key={r.id}>
                  <td>{r.name}</td>
                  <td>{RESOURCE_CATEGORY_LABEL[r.category] || r.category}</td>
                  <td>{Number(r.rental_price) > 0 ? formatPrice(r.rental_price) : 'Miễn phí'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </section>

      <Link to={`/spaces/${space.id}/booking`} className="btn btn-primary btn-lg">
        Chọn khung giờ đặt chỗ
      </Link>
    </div>
  );
}
