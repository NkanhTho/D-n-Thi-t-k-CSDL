import { Navigate, Route, Routes } from 'react-router-dom';
import Navbar from './components/Navbar';
import ProtectedRoute from './components/ProtectedRoute';

import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import SpaceSearchPage from './pages/SpaceSearchPage';
import SpaceDetailPage from './pages/SpaceDetailPage';
import BookingPage from './pages/BookingPage';
import PaymentPage from './pages/PaymentPage';
import PaymentResultPage from './pages/PaymentResultPage';
import BookingHistoryPage from './pages/BookingHistoryPage';
import ProfilePage from './pages/ProfilePage';

export default function App() {
  return (
    <>
      <Navbar />
      <main className="container page">
        <Routes>
          <Route path="/" element={<Navigate to="/spaces" replace />} />

          {/* Công khai */}
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />
          <Route path="/spaces" element={<SpaceSearchPage />} />
          <Route path="/spaces/:id" element={<SpaceDetailPage />} />
          <Route path="/payment-result" element={<PaymentResultPage />} />

          {/* Cần đăng nhập */}
          <Route
            path="/spaces/:id/booking"
            element={<ProtectedRoute><BookingPage /></ProtectedRoute>}
          />
          <Route
            path="/payment/:bookingId"
            element={<ProtectedRoute><PaymentPage /></ProtectedRoute>}
          />
          <Route
            path="/bookings"
            element={<ProtectedRoute><BookingHistoryPage /></ProtectedRoute>}
          />
          <Route
            path="/profile"
            element={<ProtectedRoute><ProfilePage /></ProtectedRoute>}
          />

          <Route path="*" element={<p className="muted">Trang không tồn tại.</p>} />
        </Routes>
      </main>
    </>
  );
}
