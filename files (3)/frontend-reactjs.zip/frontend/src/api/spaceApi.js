import client from './client';

// GET /api/bookings/spaces  (route của Người 2 được mount dưới /api/bookings)
// Backend chỉ trả về phòng status = 'AVAILABLE' và chưa có filter phía server
// => trang tìm kiếm lọc phía client.
export const getSpaces = () => client.get('/bookings/spaces');

// Backend hiện CHƯA có GET /spaces/:id. Tạm lấy cả danh sách rồi tìm theo id.
// Khi Người 2 bổ sung endpoint, chỉ cần sửa lại đúng hàm này.
export const getSpaceById = async (id) => {
  const res = await client.get('/bookings/spaces');
  const space = res.data.find((s) => String(s.id) === String(id));
  if (!space) {
    const e = new Error('Không tìm thấy phòng');
    e.response = { status: 404, data: { error: 'Không tìm thấy phòng này.' } };
    throw e;
  }
  return space;
};

export const getSpaceResources = (spaceId) =>
  client.get(`/bookings/spaces/${spaceId}/resources`);
