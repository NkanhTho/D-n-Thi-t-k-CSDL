import client from './client';

export const login = (email, password) => client.post('/auth/login', { email, password });
export const register = (payload) => client.post('/auth/register', payload);

export const getProfile = () => client.get('/users/me');
export const updateProfile = (payload) => client.put('/users/me', payload);

// Hỗ trợ / khiếu nại (Người 3). index.js cũng cần mount:
// app.use('/api/complaints', require('./routes/complaintRoutes'));
export const createComplaint = (payload) => client.post('/complaints', payload);
export const getMyComplaints = () => client.get('/complaints/my');
