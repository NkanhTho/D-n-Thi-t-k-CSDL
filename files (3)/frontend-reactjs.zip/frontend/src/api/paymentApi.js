import client from './client';

// Lưu ý: index.js của nhóm trưởng chưa mount paymentRoutes.
// Cần thêm:  app.use('/api/payments', require('./routes/paymentRoutes'));
export const createVnpayPayment = (bookingId) =>
  client.post('/payments/vnpay/create', { bookingId });

export const createMomoPayment = (bookingId) =>
  client.post('/payments/momo/create', { bookingId });

export const getTransactionStatus = (orderId) =>
  client.get(`/payments/status/${orderId}`);
