import axios from 'axios';

// Base URL trỏ tới backend của nhóm. Đổi trong file .env nếu backend chạy port khác.
const client = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:3000/api',
  headers: { 'Content-Type': 'application/json' },
});

// Tự động gắn JWT (backend dùng middleware verifyToken -> header Authorization: Bearer <token>)
client.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Token hết hạn -> đẩy về trang đăng nhập
client.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err.response?.status === 401 && localStorage.getItem('token')) {
      localStorage.removeItem('token');
      localStorage.removeItem('role');
      window.location.href = '/login';
    }
    return Promise.reject(err);
  }
);

// Lấy câu thông báo lỗi từ backend (backend trả về { error } hoặc { message })
export function getErrorMessage(err, fallback = 'Có lỗi xảy ra, thử lại sau.') {
  return err.response?.data?.error || err.response?.data?.message || fallback;
}

export default client;
