import client from './client';

// POST /api/bookings/check-availability  { spaceId, startTime, endTime }
export const checkAvailability = (payload) =>
  client.post('/bookings/check-availability', payload);

// POST /api/bookings  { spaceId, resourceIds, startTime, endTime, totalPrice }
// Trả về { message, bookingId, qrCodeHash }, booking ở trạng thái PENDING
export const createBooking = (payload) => client.post('/bookings', payload);

// Backend CHƯA có API lịch sử đặt chỗ của chính user.
// Xem backend-patch/bookingHistory.patch.js để nhờ Người 2 thêm vào.
export const getMyBookings = () => client.get('/bookings/my');
