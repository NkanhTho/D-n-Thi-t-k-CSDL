// Định dạng tiền VND: 250000 -> "250.000 ₫"
export function formatPrice(value) {
  const n = Number(value || 0);
  return n.toLocaleString('vi-VN') + ' \u20AB';
}

// Chuyển Date -> chuỗi MySQL DATETIME 'YYYY-MM-DD HH:MM:SS' (cột start_time/end_time)
export function toMysqlDatetime(date) {
  const p = (x) => String(x).padStart(2, '0');
  return (
    `${date.getFullYear()}-${p(date.getMonth() + 1)}-${p(date.getDate())} ` +
    `${p(date.getHours())}:${p(date.getMinutes())}:00`
  );
}

// Ghép ngày 'YYYY-MM-DD' + giờ (số) thành chuỗi MySQL DATETIME
export function buildDatetime(dateStr, hour) {
  const p = (x) => String(x).padStart(2, '0');
  return `${dateStr} ${p(hour)}:00:00`;
}

// Hiển thị datetime từ backend cho người dùng đọc
export function formatDatetime(value) {
  if (!value) return '—';
  const d = new Date(String(value).replace(' ', 'T'));
  if (isNaN(d)) return String(value);
  return d.toLocaleString('vi-VN', {
    day: '2-digit', month: '2-digit', year: 'numeric',
    hour: '2-digit', minute: '2-digit',
  });
}

export function todayStr() {
  const p = (x) => String(x).padStart(2, '0');
  const d = new Date();
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

// spaces.type là ENUM('DARKROOM','STUDIO')
export const SPACE_TYPE_LABEL = {
  DARKROOM: 'Phòng tối',
  STUDIO: 'Studio chụp ảnh',
};

// bookings.status là ENUM(...)
export const BOOKING_STATUS_LABEL = {
  PENDING: 'Chờ thanh toán',
  CONFIRMED: 'Đã xác nhận',
  CHECKED_IN: 'Đang sử dụng',
  COMPLETED: 'Hoàn thành',
  CANCELLED: 'Đã huỷ',
};

// resources.category là ENUM(...)
export const RESOURCE_CATEGORY_LABEL = {
  CAMERA: 'Máy ảnh',
  LENS: 'Ống kính',
  ENLARGER: 'Máy phóng ảnh',
  SCANNER: 'Máy quét phim',
  LIGHTING: 'Thiết bị chiếu sáng',
  CHEMICAL: 'Hoá chất',
  PAPER: 'Giấy ảnh',
};

// specifications là cột JSON do Người 2 tự do định nghĩa.
// Bảng spaces chưa có cột khu vực riêng, nên khu vực được đọc từ JSON này.
export function parseSpecs(specifications) {
  if (!specifications) return {};
  if (typeof specifications === 'object') return specifications;
  try {
    return JSON.parse(specifications);
  } catch {
    return {};
  }
}

export function getArea(space) {
  const specs = parseSpecs(space.specifications);
  return specs.area || specs.district || specs.location || specs.city || '';
}
