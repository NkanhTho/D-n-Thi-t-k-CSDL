const express = require('express');
const router = express.Router();
const { verifyToken } = require('../middleware/authMiddleware');
const controller = require('../controllers/chatbotController');

router.post('/', verifyToken, controller.chat);

module.exports = router;
