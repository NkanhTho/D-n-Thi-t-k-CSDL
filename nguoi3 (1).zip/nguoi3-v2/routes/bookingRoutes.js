// Route này NỐI VÀO controller của Người 2 (Transaction_safe_Locking + Backend
// đã gộp thành 1 file bookingController.js - xem ghi chú trong README).
// Người 3 viết route này để tích hợp, nhưng nên xác nhận lại với Người 2/nhóm trưởng
// tên file/đường dẫn thực tế trước khi merge.
const express = require('express');
const router = express.Router();
const { verifyToken, checkRole } = require('../middleware/authMiddleware');
const controller = require('../controllers/bookingController'); // của Người 2

router.post('/check-availability', controller.checkAvailability);
router.post('/', verifyToken, controller.createBooking);
router.post('/checkin', verifyToken, checkRole('provider', 'admin'), controller.checkIn);
router.post('/:bookingId/checkout', verifyToken, checkRole('provider', 'admin'), controller.checkOut);

module.exports = router;
