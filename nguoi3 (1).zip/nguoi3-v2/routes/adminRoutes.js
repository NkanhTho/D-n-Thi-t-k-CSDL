const express = require('express');
const router = express.Router();
const { verifyToken, checkRole } = require('../middleware/authMiddleware');
const controller = require('../controllers/adminController');

router.use(verifyToken, checkRole('admin'));

router.get('/providers/pending', controller.getPendingProviders);
router.put('/providers/:id/approve', controller.approveProvider);
router.delete('/providers/:id/reject', controller.rejectProvider);

router.get('/spaces', controller.getAllSpaces);
router.put('/spaces/:id/status', controller.setSpaceStatus);

router.get('/resources', controller.getAllResources);
router.put('/resources/:id/status', controller.setResourceStatus);

router.get('/stats', controller.getDashboardStats);

module.exports = router;
