const express = require('express');
const router = express.Router();
const { verifyToken } = require('../middleware/authMiddleware');
const controller = require('../controllers/paymentController');

router.post('/vnpay/create', verifyToken, controller.createVnpayPayment);
router.get('/vnpay/return', controller.vnpayReturn);

router.post('/momo/create', verifyToken, controller.createMomoPayment);
router.post('/momo/ipn', controller.momoIpn);
router.get('/momo/return', controller.momoReturn);

router.get('/status/:orderId', verifyToken, controller.getTransactionStatus);

module.exports = router;
