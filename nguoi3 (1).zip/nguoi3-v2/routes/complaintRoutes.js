const express = require('express');
const router = express.Router();
const { verifyToken, checkRole } = require('../middleware/authMiddleware');
const controller = require('../controllers/complaintController');

router.post('/', verifyToken, controller.createComplaint);
router.get('/my', verifyToken, controller.getMyComplaints);
router.get('/', verifyToken, checkRole('admin'), controller.getAllComplaints);
router.put('/:id/resolve', verifyToken, checkRole('admin'), controller.resolveComplaint);

module.exports = router;
