// LƯU Ý: file này giả định db.js đã được đổi sang mysql2/promise (xem config/db.js.PROPOSAL)
// db.query(sql, params) trả về Promise, destructure [rows] = await db.query(...)

const db = require('../config/db');
const vnpayUtil = require('../utils/vnpay.util');
const momoUtil = require('../utils/momo.util');

// ============ VNPAY ============

// User bấm "Thanh toán" cho 1 booking đã tạo (booking.status = 'PENDING', total_price đã có sẵn)
exports.createVnpayPayment = async (req, res) => {
  const { bookingId } = req.body;
  const userId = req.user.id;

  try {
    const [rows] = await db.query(
      'SELECT * FROM bookings WHERE id = ? AND user_id = ?',
      [bookingId, userId]
    );
    if (rows.length === 0) return res.status(404).json({ error: 'Không tìm thấy booking' });

    const booking = rows[0];
    if (booking.status !== 'PENDING') {
      return res.status(400).json({ error: `Booking đang ở trạng thái ${booking.status}, không thể thanh toán` });
    }

    const orderId = `${bookingId}_${Date.now()}`;
    const amount = booking.total_price;

    await db.query(
      'INSERT INTO transactions (booking_id, amount, payment_method, order_id) VALUES (?, ?, "vnpay", ?)',
      [bookingId, amount, orderId]
    );

    const ipAddr = req.headers['x-forwarded-for'] || req.socket.remoteAddress || '127.0.0.1';
    const paymentUrl = vnpayUtil.createPaymentUrl({
      amount,
      orderId,
      orderInfo: `Thanh toan booking ${bookingId}`,
      ipAddr,
    });

    res.json({ paymentUrl });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// VNPay redirect user về đây sau khi thanh toán -> verify checksum + cập nhật booking sang CONFIRMED
exports.vnpayReturn = async (req, res) => {
  const isValid = vnpayUtil.verifyReturnUrl(req.query);
  if (!isValid) return res.status(400).json({ error: 'Chữ ký không hợp lệ' });

  const { vnp_TxnRef, vnp_ResponseCode, vnp_TransactionNo } = req.query;
  const newStatus = vnp_ResponseCode === '00' ? 'success' : 'failed';
  const bookingId = vnp_TxnRef.split('_')[0];

  try {
    await db.query(
      'UPDATE transactions SET status = ?, transaction_ref = ? WHERE order_id = ?',
      [newStatus, vnp_TransactionNo, vnp_TxnRef]
    );

    if (newStatus === 'success') {
      // Chuyển booking từ PENDING -> CONFIRMED (Người 2 quy định chỉ CONFIRMED mới check-in được)
      await db.query('UPDATE bookings SET status = "CONFIRMED" WHERE id = ?', [bookingId]);
    }

    res.json({ message: newStatus === 'success' ? 'Thanh toán thành công, booking đã được xác nhận' : 'Thanh toán thất bại', status: newStatus });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// ============ MOMO ============

exports.createMomoPayment = async (req, res) => {
  const { bookingId } = req.body;
  const userId = req.user.id;

  try {
    const [rows] = await db.query('SELECT * FROM bookings WHERE id = ? AND user_id = ?', [bookingId, userId]);
    if (rows.length === 0) return res.status(404).json({ error: 'Không tìm thấy booking' });

    const booking = rows[0];
    if (booking.status !== 'PENDING') {
      return res.status(400).json({ error: `Booking đang ở trạng thái ${booking.status}, không thể thanh toán` });
    }

    const orderId = `${bookingId}_${Date.now()}`;
    const amount = Math.round(booking.total_price);

    await db.query(
      'INSERT INTO transactions (booking_id, amount, payment_method, order_id) VALUES (?, ?, "momo", ?)',
      [bookingId, amount, orderId]
    );

    const momoRes = await momoUtil.createPaymentRequest({
      amount,
      orderId,
      orderInfo: `Thanh toan booking ${bookingId}`,
    });

    res.json({ paymentUrl: momoRes.payUrl });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// MoMo gọi server-to-server (IPN) sau khi thanh toán xong -> nguồn xác nhận đáng tin cậy
exports.momoIpn = async (req, res) => {
  const isValid = momoUtil.verifyIpnSignature(req.body);
  if (!isValid) return res.status(400).json({ message: 'Invalid signature' });

  const { orderId, resultCode, transId } = req.body;
  const newStatus = resultCode === 0 ? 'success' : 'failed';
  const bookingId = orderId.split('_')[0];

  try {
    await db.query(
      'UPDATE transactions SET status = ?, transaction_ref = ? WHERE order_id = ?',
      [newStatus, transId, orderId]
    );

    if (newStatus === 'success') {
      await db.query('UPDATE bookings SET status = "CONFIRMED" WHERE id = ?', [bookingId]);
    }

    res.status(204).send();
  } catch (err) {
    res.status(500).json({ message: 'DB error' });
  }
};

exports.momoReturn = (req, res) => {
  res.json({ message: 'Đã quay lại từ MoMo, trạng thái thật xác nhận qua IPN', query: req.query });
};

exports.getTransactionStatus = async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM transactions WHERE order_id = ?', [req.params.orderId]);
    if (rows.length === 0) return res.status(404).json({ error: 'Không tìm thấy giao dịch' });
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
