const db = require('../config/db');

// ---- Duyệt provider ----
exports.getPendingProviders = async (req, res) => {
  try {
    const [rows] = await db.query(
      'SELECT id, name, email, created_at FROM users WHERE role = "provider" AND is_approved = FALSE'
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.approveProvider = async (req, res) => {
  try {
    const [result] = await db.query(
      'UPDATE users SET is_approved = TRUE WHERE id = ? AND role = "provider"',
      [req.params.id]
    );
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Không tìm thấy provider' });
    res.json({ message: 'Đã duyệt provider' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.rejectProvider = async (req, res) => {
  try {
    const [result] = await db.query(
      'DELETE FROM users WHERE id = ? AND role = "provider" AND is_approved = FALSE',
      [req.params.id]
    );
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Không tìm thấy provider chờ duyệt' });
    res.json({ message: 'Đã từ chối provider' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// ---- Quản lý "danh mục" ----
// GHI CHÚ: schema của Người 2 không có bảng categories riêng, mà dùng ENUM
// `type` trong spaces (DARKROOM/STUDIO) và `category` trong resources
// (CAMERA/LENS/ENLARGER/...). Vì ENUM cố định ở DB nên admin không "tạo mới"
// danh mục được, chỉ có thể xem/thống kê theo các loại có sẵn, hoặc đổi
// trạng thái từng space/resource. Hai API dưới đây thay thế cho phần
// "quản lý danh mục" ban đầu — nên xác nhận lại với nhóm trưởng.

exports.getAllSpaces = async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT s.*, u.name AS provider_name FROM spaces s
       JOIN users u ON s.provider_id = u.id`
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Admin có thể vô hiệu hoá 1 space vi phạm (không xoá cứng để giữ lịch sử booking)
exports.setSpaceStatus = async (req, res) => {
  const { status } = req.body; // 'AVAILABLE' | 'MAINTENANCE' | 'INACTIVE'
  try {
    const [result] = await db.query('UPDATE spaces SET status = ? WHERE id = ?', [status, req.params.id]);
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Không tìm thấy space' });
    res.json({ message: 'Đã cập nhật trạng thái space' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getAllResources = async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM resources');
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.setResourceStatus = async (req, res) => {
  const { status } = req.body; // 'AVAILABLE' | 'IN_USE' | 'MAINTENANCE' | 'DAMAGED'
  try {
    const [result] = await db.query('UPDATE resources SET status = ? WHERE id = ?', [status, req.params.id]);
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Không tìm thấy resource' });
    res.json({ message: 'Đã cập nhật trạng thái resource' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// ---- Thống kê ----
exports.getDashboardStats = async (req, res) => {
  try {
    const [[{ totalUsers }]] = await db.query('SELECT COUNT(*) AS totalUsers FROM users');
    const [[{ totalBookings }]] = await db.query('SELECT COUNT(*) AS totalBookings FROM bookings');
    const [[{ totalRevenue }]] = await db.query(
      'SELECT COALESCE(SUM(amount), 0) AS totalRevenue FROM transactions WHERE status = "success"'
    );
    res.json({ totalUsers, totalBookings, totalRevenue });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
