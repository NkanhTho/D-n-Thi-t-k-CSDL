const db = require('../config/db');

exports.createComplaint = async (req, res) => {
  const { bookingId, content } = req.body;
  const userId = req.user.id;

  if (!content) return res.status(400).json({ error: 'Nội dung khiếu nại không được để trống' });

  try {
    const [result] = await db.query(
      'INSERT INTO complaints (user_id, booking_id, content) VALUES (?, ?, ?)',
      [userId, bookingId || null, content]
    );
    res.status(201).json({ message: 'Đã gửi khiếu nại, admin sẽ xử lý sớm', id: result.insertId });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getMyComplaints = async (req, res) => {
  try {
    const [rows] = await db.query(
      'SELECT * FROM complaints WHERE user_id = ? ORDER BY created_at DESC',
      [req.user.id]
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getAllComplaints = async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT c.*, u.name AS user_name, u.email FROM complaints c
       JOIN users u ON c.user_id = u.id
       ORDER BY c.status ASC, c.created_at DESC`
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.resolveComplaint = async (req, res) => {
  const { adminResponse } = req.body;
  try {
    const [result] = await db.query(
      'UPDATE complaints SET status = "resolved", admin_response = ? WHERE id = ?',
      [adminResponse, req.params.id]
    );
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Không tìm thấy khiếu nại' });
    res.json({ message: 'Đã xử lý khiếu nại' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
