const db = require('../config/db');
const { askAI } = require('../utils/openai');

const FAQ_RULES = [
  { keywords: ['hủy', 'huỷ', 'cancel'], reply: 'Bạn có thể hủy booking trong vòng 24h trước giờ đặt mà không mất phí. Vào mục "Booking của tôi" để hủy.' },
  { keywords: ['thanh toán', 'payment', 'trả tiền'], reply: 'Hiện hỗ trợ thanh toán qua VNPay và MoMo. Sau khi đặt chỗ, bạn sẽ được chuyển đến trang thanh toán.' },
  { keywords: ['check-in', 'checkin', 'qr'], reply: 'Sau khi thanh toán thành công, booking chuyển sang "Đã xác nhận". Đưa mã QR cho nhân viên khi đến nơi để check-in.' },
  { keywords: ['thiết bị', 'resource', 'máy'], reply: 'Bạn có thể chọn thêm thiết bị (máy ảnh, đèn, máy quét...) khi đặt không gian, hệ thống sẽ kiểm tra thiết bị còn trống trong khung giờ bạn chọn.' },
];

function matchFAQ(message) {
  const lower = message.toLowerCase();
  const matched = FAQ_RULES.find((rule) => rule.keywords.some((kw) => lower.includes(kw)));
  return matched ? matched.reply : null;
}

exports.chat = async (req, res) => {
  const { message } = req.body;
  const userId = req.user ? req.user.id : null;

  if (!message) return res.status(400).json({ error: 'Vui lòng nhập câu hỏi' });

  const ruleReply = matchFAQ(message);
  if (ruleReply) {
    await logChat(userId, message, ruleReply);
    return res.json({ reply: ruleReply, source: 'rule-based' });
  }

  try {
    const aiReply = await askAI(message);
    await logChat(userId, message, aiReply);
    res.json({ reply: aiReply, source: 'ai' });
  } catch (err) {
    res.status(500).json({ error: 'Chatbot đang gặp sự cố, vui lòng thử lại sau' });
  }
};

async function logChat(userId, message, reply) {
  try {
    await db.query('INSERT INTO chat_logs (user_id, message, reply) VALUES (?, ?, ?)', [userId, message, reply]);
  } catch (e) {
    // không chặn response chính nếu log lỗi
  }
}
