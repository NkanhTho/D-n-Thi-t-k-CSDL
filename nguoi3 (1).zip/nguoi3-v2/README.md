# Người 3 — bản viết lại dựa trên schema của Người 2

## ⚠️ VIỆC CẦN LÀM TRƯỚC TIÊN — báo nhóm trưởng

Code của Người 2 dùng `await db.query(...)` và `db.getConnection()` (kiểu
**mysql2/promise**). Nhưng `db.js` gốc hiện tại dùng `mysql.createConnection`
kiểu **callback**. Hai kiểu này không tương thích.

→ Xem file `config/db.js.PROPOSAL` — đây là đề xuất `db.js` mới. Cần nhóm
trưởng + người viết `authController.js`/`userController.js` (Người 1) đồng ý
đổi, vì sau khi đổi, các hàm `db.query(sql, params, callback)` cũ trong 2 file
đó phải viết lại thành `const [rows] = await db.query(sql, params)`.

**Không tự ý đổi `db.js` rồi push một mình** — việc này ảnh hưởng toàn bộ
team, cần thống nhất trước.

## Những gì đã thay đổi so với bản trước

| Trước (service_packages) | Giờ (theo Người 2) |
|---|---|
| Bảng `service_packages` | Bảng `spaces` (không gian: DARKROOM/STUDIO) + `resources` (thiết bị đi kèm) |
| `checkinController.js` tự viết | Người 2 đã viết `checkAvailability`, `createBooking`, `checkIn`, `checkOut` (2 file gộp lại) |
| QR tự sinh token riêng | Dùng `qr_code_hash` có sẵn trong bảng `bookings` của Người 2 |
| Booking status: pending/checked_in/checked_out | Người 2 dùng: PENDING → CONFIRMED → CHECKED_IN → COMPLETED (hoặc CANCELLED) |
| Bảng `categories` riêng | Không còn — dùng ENUM `type`/`category` có sẵn trong `spaces`/`resources` |

## Người 3 giờ chỉ cần làm

1. **Thanh toán (VNPay/MoMo)** — `controllers/paymentController.js`
   - Lấy `total_price` trực tiếp từ `bookings` (Người 2 đã tính sẵn khi tạo booking)
   - Sau khi thanh toán `success` → cập nhật `bookings.status = 'CONFIRMED'`
     (để Người 2's `checkIn` function chạy được, vì nó yêu cầu status = CONFIRMED)
2. **Admin** — `controllers/adminController.js`
   - Duyệt provider (giữ nguyên)
   - Thay "quản lý danh mục" bằng quản lý trạng thái `spaces`/`resources`
     (xem ghi chú trong file, cần xác nhận lại với nhóm trưởng)
3. **Khiếu nại** — không đổi logic, chỉ đổi sang `async/await`
4. **AI Chatbot** — không đổi logic, chỉ đổi sang `async/await`

## Việc KHÔNG cần làm nữa (Người 2 đã làm)
- Tạo booking, kiểm tra trùng lịch (`checkAvailability`, `createBooking` với transaction/lock)
- Check-in / Check-out xác thực QR

## File `routes/bookingRoutes.js`
Mình viết route để nối vào controller của Người 2, NHƯNG:
- Cần hỏi Người 2 tên file thật họ đặt là gì (2 file `Transaction_safe_Locking`
  và `Backend` họ gửi chưa rõ tên/`module.exports` cuối file — có thể họ đã
  gộp thành 1 file `bookingController.js` hoặc để 2 file riêng)
- Sửa `require('../controllers/bookingController')` trong route cho khớp
  đường dẫn thật

## Các bước tiếp theo
1. Xác nhận với nhóm trưởng về `db.js` (Promise Pool) — **việc quan trọng nhất**
2. Chạy `sql/schema_addon.sql` SAU KHI đã có schema của Người 2 (`spaces`,
   `resources`, `bookings`, `booking_resources`, `maintenance_schedules`)
3. Xác nhận tên file thật của controller Người 2 để sửa `require(...)` trong
   `routes/bookingRoutes.js`
4. Xác nhận cách "quản lý danh mục" — dùng `spaces`/`resources` có sẵn (như
   mình đề xuất) hay team vẫn muốn có bảng `categories` động riêng
5. Cài package: `npm install qrcode axios moment qs dotenv`
6. Test lần lượt: đăng ký provider → duyệt provider → tạo space/resource (API
   của Người 2) → check availability → tạo booking → thanh toán → check-in
