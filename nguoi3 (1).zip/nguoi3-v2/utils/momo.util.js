const crypto = require('crypto');
const axios = require('axios');
const momoConfig = require('../config/momo.config');

async function createPaymentRequest({ amount, orderId, orderInfo }) {
  const requestId = orderId + '_' + Date.now();
  const extraData = '';
  const requestType = 'payWithMethod';

  const rawSignature =
    `accessKey=${momoConfig.accessKey}` +
    `&amount=${amount}` +
    `&extraData=${extraData}` +
    `&ipnUrl=${momoConfig.ipnUrl}` +
    `&orderId=${orderId}` +
    `&orderInfo=${orderInfo}` +
    `&partnerCode=${momoConfig.partnerCode}` +
    `&redirectUrl=${momoConfig.redirectUrl}` +
    `&requestId=${requestId}` +
    `&requestType=${requestType}`;

  const signature = crypto.createHmac('sha256', momoConfig.secretKey).update(rawSignature).digest('hex');

  const body = {
    partnerCode: momoConfig.partnerCode,
    partnerName: 'Test',
    storeId: 'MomoTestStore',
    requestId,
    amount,
    orderId,
    orderInfo,
    redirectUrl: momoConfig.redirectUrl,
    ipnUrl: momoConfig.ipnUrl,
    lang: 'vi',
    extraData,
    requestType,
    signature,
  };

  const response = await axios.post(momoConfig.endpoint, body, {
    headers: { 'Content-Type': 'application/json' },
  });

  return response.data;
}

function verifyIpnSignature(payload) {
  const {
    partnerCode, orderId, requestId, amount, orderInfo, orderType,
    transId, resultCode, message, payType, responseTime, extraData, signature,
  } = payload;

  const rawSignature =
    `accessKey=${momoConfig.accessKey}` +
    `&amount=${amount}` +
    `&extraData=${extraData}` +
    `&message=${message}` +
    `&orderId=${orderId}` +
    `&orderInfo=${orderInfo}` +
    `&orderType=${orderType}` +
    `&partnerCode=${partnerCode}` +
    `&payType=${payType}` +
    `&requestId=${requestId}` +
    `&responseTime=${responseTime}` +
    `&resultCode=${resultCode}` +
    `&transId=${transId}`;

  const expectedSignature = crypto.createHmac('sha256', momoConfig.secretKey).update(rawSignature).digest('hex');
  return expectedSignature === signature;
}

module.exports = { createPaymentRequest, verifyIpnSignature };
