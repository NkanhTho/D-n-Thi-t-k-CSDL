const crypto = require('crypto');
const qs = require('qs');
const moment = require('moment');
const vnpayConfig = require('../config/vnpay.config');

function sortObject(obj) {
  const sorted = {};
  const keys = Object.keys(obj).sort();
  keys.forEach((key) => {
    sorted[key] = obj[key];
  });
  return sorted;
}

function createPaymentUrl({ amount, orderId, orderInfo, ipAddr }) {
  const createDate = moment().format('YYYYMMDDHHmmss');

  let vnpParams = {
    vnp_Version: '2.1.0',
    vnp_Command: 'pay',
    vnp_TmnCode: vnpayConfig.tmnCode,
    vnp_Locale: 'vn',
    vnp_CurrCode: 'VND',
    vnp_TxnRef: orderId,
    vnp_OrderInfo: orderInfo,
    vnp_OrderType: 'other',
    vnp_Amount: amount * 100,
    vnp_ReturnUrl: vnpayConfig.returnUrl,
    vnp_IpAddr: ipAddr,
    vnp_CreateDate: createDate,
  };

  vnpParams = sortObject(vnpParams);

  const signData = qs.stringify(vnpParams, { encode: false });
  const hmac = crypto.createHmac('sha512', vnpayConfig.hashSecret);
  const signed = hmac.update(Buffer.from(signData, 'utf-8')).digest('hex');

  vnpParams.vnp_SecureHash = signed;

  return `${vnpayConfig.vnpUrl}?${qs.stringify(vnpParams, { encode: false })}`;
}

function verifyReturnUrl(queryParams) {
  const vnpParams = { ...queryParams };
  const secureHash = vnpParams.vnp_SecureHash;

  delete vnpParams.vnp_SecureHash;
  delete vnpParams.vnp_SecureHashType;

  const sortedParams = sortObject(vnpParams);
  const signData = qs.stringify(sortedParams, { encode: false });
  const hmac = crypto.createHmac('sha512', vnpayConfig.hashSecret);
  const checkSum = hmac.update(Buffer.from(signData, 'utf-8')).digest('hex');

  return checkSum === secureHash;
}

module.exports = { createPaymentUrl, verifyReturnUrl };
