const QRCode = require('qrcode');

// Người 2 đã tự sinh qr_code_hash trong bookings (sha256 hash).
// Người 3 chỉ cần chuyển hash đó thành ẢNH QR để FE hiển thị cho user,
// KHÔNG tự sinh token riêng nữa (tránh 2 nguồn sự thật khác nhau).
async function generateQrImage(bookingId, qrCodeHash) {
  // Encode cả bookingId lẫn hash để khi quét, backend biết cần so khớp với bookingId nào
  const payload = JSON.stringify({ bookingId, qrCodeHash });
  return await QRCode.toDataURL(payload);
}

module.exports = { generateQrImage };
