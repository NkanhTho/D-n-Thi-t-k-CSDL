const axios = require('axios');

async function askAI(userMessage) {
  const response = await axios.post(
    'https://api.openai.com/v1/chat/completions',
    {
      model: 'gpt-4o-mini',
      messages: [
        {
          role: 'system',
          content:
            'Bạn là trợ lý ảo cho ứng dụng đặt không gian sáng tạo (studio/darkroom) kèm thiết bị. ' +
            'Trả lời ngắn gọn, thân thiện, chỉ tư vấn về đặt chỗ, thiết bị, thanh toán, chính sách hủy. ' +
            'Nếu không chắc, hãy khuyên người dùng liên hệ admin.',
        },
        { role: 'user', content: userMessage },
      ],
      max_tokens: 300,
    },
    {
      headers: {
        Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
        'Content-Type': 'application/json',
      },
    }
  );

  return response.data.choices[0].message.content;
}

module.exports = { askAI };
