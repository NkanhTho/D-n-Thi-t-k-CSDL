-- ===================================================================
-- SCHEMA BỔ SUNG CỦA NGƯỜI 3 — chạy SAU khi đã chạy Database_Schema.sql
-- của Người 2 (bảng users, spaces, resources, bookings, booking_resources,
-- maintenance_schedules đã có sẵn)
-- ===================================================================

-- Cột duyệt provider (users.role = 'provider' cần admin duyệt mới được đăng gói)
ALTER TABLE users ADD COLUMN is_approved BOOLEAN DEFAULT FALSE;

-- Giao dịch thanh toán, gắn với bookings của Người 2 (KHÔNG tạo lại bảng bookings)
CREATE TABLE transactions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  booking_id INT NOT NULL,
  amount DECIMAL(10, 2) NOT NULL,
  payment_method ENUM('vnpay', 'momo') NOT NULL,
  status ENUM('pending', 'success', 'failed') DEFAULT 'pending',
  transaction_ref VARCHAR(255),
  order_id VARCHAR(255) UNIQUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (booking_id) REFERENCES bookings(id)
);

-- Khiếu nại, gắn với bookings của Người 2
CREATE TABLE complaints (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  booking_id INT,
  content TEXT NOT NULL,
  status ENUM('open', 'resolved') DEFAULT 'open',
  admin_response TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (booking_id) REFERENCES bookings(id)
);

-- Lịch sử chat AI (tuỳ chọn)
CREATE TABLE chat_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  message TEXT NOT NULL,
  reply TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- GHI CHÚ: không còn bảng `categories` / `service_packages` riêng nữa.
-- Người 2 đã dùng cột `type` (ENUM DARKROOM/STUDIO) trong bảng `spaces`
-- và `category` (ENUM CAMERA/LENS/...) trong bảng `resources` thay cho "danh mục".
-- => Phần "Trang Admin: quản lý danh mục" của Người 3 cần trao đổi lại với
--    nhóm trưởng: có cần bảng categories động nữa không, hay quản lý qua
--    spaces/resources có sẵn là đủ (mình tạm code theo hướng dùng spaces/resources).
